<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductTypeCategory extends Model
{
    protected $table = 'product_type_category';
    public $timestamps = false;
}
