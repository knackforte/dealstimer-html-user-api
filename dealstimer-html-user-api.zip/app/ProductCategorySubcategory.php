<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductCategorySubcategory extends Model
{
    protected $table = 'product_category_subcategory';
    public $timestamps = false;
}
